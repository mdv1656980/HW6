﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _13_A
{
    public partial class Form1 : Form
    {

        int n = 0; //number of bernoulli r.v.s
        int m = 0; //number of paths
        decimal p = 0; //probability
        int j = 0;
        decimal epsilon = 0;
        Random r;
        List<Dictionary<int, decimal>> listOfPaths;
        Dictionary<Interval, FrequenciesForValue> nDistribution;
        Dictionary<Interval, FrequenciesForValue> njDistribution;

        // graphics
        public Bitmap b;
        public Graphics g;
        public Font SmallFont = new Font("Calibri", 10f, FontStyle.Regular, GraphicsUnit.Pixel);
        Color[] colors = { Color.Blue, Color.Red, Color.Green, Color.Purple, Color.Aquamarine, Color.Brown, Color.Orange, Color.Cyan, Color.Magenta, Color.Lavender, Color.Coral };

        // viewport
        public Rectangle Viewport;

        // window'
        public decimal MinX_Window = 0;
        public decimal MaxX_Window = 1000;
        public decimal MinY_Window = 0;
        public decimal MaxY_WIndow = 1;
        public decimal RangeX;
        public decimal RangeY;

        //histograms vars
        decimal intervalSize;
        decimal startingPoint;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeGraphics()
        {
            b = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            g = Graphics.FromImage(b);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            RangeX = MaxX_Window - MinX_Window;
            RangeY = MaxY_WIndow - MinY_Window;
            Viewport = new Rectangle(5, 5, this.pictureBox1.Width - 10, this.pictureBox1.Height - 10);

            //TODO: not working ....
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pictureBox1);
            this.pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;

            //Setting max x window
            this.MaxX_Window = this.n;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            int.TryParse(n_textBox.Text, out this.n);
            int.TryParse(m_textBox.Text, out this.m);
            decimal.TryParse(p_textBox.Text, out this.p);
            int.TryParse(j_textBox.Text, out this.j);
            decimal.TryParse(eps_textBox.Text, out this.epsilon);
            r = new Random();
            listOfPaths = new List<Dictionary<int, decimal>>();
            nDistribution = new Dictionary<Interval, FrequenciesForValue>();
            njDistribution = new Dictionary<Interval, FrequenciesForValue>();

            //init graphics
            InitializeGraphics();

            //build list of paths to draw
            for (int i = 0; i < m; i++)
            {
                Dictionary<int, decimal> pointsOfPath = generatePoints(n);
                listOfPaths.Add(pointsOfPath);
            }

            //calculate distributions on n and n/j
            List<decimal> nFreqencies = new List<decimal>();
            List<decimal> njFreqencies = new List<decimal>();
            int linesInStripAtN = 0;
            int linesInStripAtNJ = 0;
            foreach (Dictionary<int, decimal> path in listOfPaths)
            {

                //(ripetere i seguenti step sia per n che per n/j)
                // 1) seleziona i valori ad n
                decimal nFreq; 
                decimal njFreq;
                path.TryGetValue(this.n, out nFreq);
                path.TryGetValue((this.n)/j, out njFreq);

                // 2) aggiugili ad una lista (saranno le observations)
                nFreqencies.Add(nFreq);
                njFreqencies.Add(njFreq);

                // 3) controlla se la loro linea è t.c. -> p-eps < line < p+eps
                if( (this.p - this.epsilon) < nFreq && nFreq < (this.p + this.epsilon))
                {
                    linesInStripAtN++;
                }
                if ((this.p - this.epsilon) < njFreq && nFreq < (this.p + this.epsilon))
                {
                    linesInStripAtNJ++;
                }
            }
            // 3) calcolane la distribuzione (univariate) e salva la distribuzione per disegnarci un istogramma
            intervalSize = (decimal)1 / (decimal)100;
            startingPoint = (decimal)1 / (decimal)2;
            nDistribution = UnivariateDistribution_ContinuousVariable(nFreqencies, intervalSize, startingPoint);
            njDistribution = UnivariateDistribution_ContinuousVariable(njFreqencies, intervalSize, startingPoint);

            //for each path draw its line + draw histograms
            drawGraphics();

            //set lines in strip values
            int percentNJ = (int)Math.Round((double)(100 * linesInStripAtNJ) / this.m);
            int percentN = (int)Math.Round((double)(100 * linesInStripAtN) / this.m);
            this.labelNJ.Text = linesInStripAtNJ.ToString() + " -> ( " + percentNJ.ToString() + "% )";
            this.labelN.Text = linesInStripAtN.ToString() + " -> ( " + percentN.ToString() + "% )";

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            this.n_textBox.Clear();
            this.m_textBox.Clear();
            this.p_textBox.Clear();
            this.j_textBox.Clear();
            this.eps_textBox.Clear();

            this.n = 0;
            this.m = 0;
            this.p = 0;
            this.j = 0;
            this.epsilon = 0;

            this.pictureBox1.Image = null;
        }

        private void drawGraphics()
        {
            g.Clear(Color.Black);
            Pen rectanglePen = new Pen(Color.White, 2);
            g.DrawRectangle(rectanglePen, Viewport);

            // DRAWING POINTS AND LINES
            int i = 0;
            foreach(Dictionary<int, decimal> path in listOfPaths)
            {
                List<PointF> pointsOfPath = new List<PointF>();
                Brush brush = new SolidBrush(Color.FromArgb(64, colors[i % colors.Length]));    //transparency
                Pen pen = new Pen(Color.FromArgb(64, colors[i % colors.Length]), 2);            //transparency
                foreach (KeyValuePair<int, decimal> kvp in path)
                {
                    int x = X_Viewport(kvp.Key, Viewport, MinX_Window, RangeX);
                    int y = Y_Viewport(kvp.Value, Viewport, MinY_Window, RangeY);

                    pointsOfPath.Add(new PointF(x, y));
                    
                    //point
                    g.FillEllipse(brush, new Rectangle(new Point(x, y), new Size(2, 2)));
                }

                if (pointsOfPath.Count > 1)
                {
                    //line
                    g.DrawLines(pen, pointsOfPath.ToArray());
                }
                i++;
            }

            // DRAWING P LINE
            Pen pen2 = new Pen(Color.White, 3);
            int pxStart = X_Viewport(0, Viewport, MinX_Window, RangeX);
            int pxEnd = X_Viewport(this.MaxX_Window, Viewport, MinX_Window, RangeX);
            int py = Y_Viewport(this.p, Viewport, MinY_Window, RangeY);
            g.DrawLine(pen2, new Point(pxStart, py), new Point(pxEnd, py));

            // DRAWING P+EPSILON LINE
            Pen pen3 = new Pen(Color.White, 2);
            int pyPlusEpsilon = Y_Viewport(this.p + this.epsilon, Viewport, MinY_Window, RangeY);
            g.DrawLine(pen3, new Point(pxStart, pyPlusEpsilon), new Point(pxEnd, pyPlusEpsilon));

            // DRAWING P-EPSILON LINE
            int pyMinusEpsilon = Y_Viewport(this.p - this.epsilon, Viewport, MinY_Window, RangeY);
            g.DrawLine(pen3, new Point(pxStart, pyMinusEpsilon), new Point(pxEnd, pyMinusEpsilon));

            //DRAWING N/J VERTICAL LINE
            int pyStartNJ = Y_Viewport(0, Viewport, MinY_Window, RangeY);
            int pyEndNJ = Y_Viewport(this.MaxY_WIndow, Viewport, MinY_Window, RangeY);
            int pxNJ = X_Viewport(this.n/this.j, Viewport, MinX_Window, RangeX);
            g.DrawLine(pen3, new Point(pxNJ, pyStartNJ), new Point(pxNJ, pyEndNJ));

            //DRAWING N VERTICAL LINE (a little before N)
            int pyStartN = Y_Viewport(0, Viewport, MinY_Window, RangeY);
            int pyEndN = Y_Viewport(this.MaxY_WIndow, Viewport, MinY_Window, RangeY);
            int pxN = X_Viewport(this.n - 50, Viewport, MinX_Window, RangeX);
            g.DrawLine(pen3, new Point(pxN, pyStartN), new Point(pxN, pyEndN));

            //DRAWING HISTOGRAM AT N/J
            float intervalMaxHeigth = 200;
            foreach(KeyValuePair<Interval, FrequenciesForValue> kvp in njDistribution)
            {
                SolidBrush brush = new SolidBrush(Color.Red);
                float cornerX = X_Viewport(this.n / this.j, Viewport, MinX_Window, RangeX);
                float cornerY = Y_Viewport(kvp.Key.LowerEnd, Viewport, MinY_Window, RangeY);
                float intervalWidth = (float)intervalSize * (float)pictureBox1.Height;
                float intervalHeigth = intervalMaxHeigth * kvp.Value.Count/m;
                g.FillRectangle(brush, cornerX, cornerY, intervalHeigth, intervalWidth);
            }

            //DRAWING HISTOGRAM AT N (a little before N)
            foreach (KeyValuePair<Interval, FrequenciesForValue> kvp in nDistribution)
            {
                SolidBrush brush = new SolidBrush(Color.Red);
                float cornerX = X_Viewport(this.n - 50, Viewport, MinX_Window, RangeX);
                float cornerY = Y_Viewport(kvp.Key.LowerEnd, Viewport, MinY_Window, RangeY);
                float intervalWidth = (float)intervalSize * (float)pictureBox1.Height;
                float intervalHeigth = intervalMaxHeigth * kvp.Value.Count / m;
                g.FillRectangle(brush, cornerX, cornerY, intervalHeigth, intervalWidth);
            }

            addLabel(g, pictureBox1, "Law of Large Numbers");
            this.pictureBox1.Image = b;
        }

        void addLabel(Graphics g, PictureBox pictureBox, String title)
        {
            Font font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Regular);
            SizeF stringSize = new SizeF();
            stringSize = g.MeasureString(title, font);
            g.DrawString(title, font, new SolidBrush(Color.White), pictureBox.Left + 20, 20);
        }

        // ==========================================================================================================='
        // MANUAL TRANSFORMATION'

        // X to x transformation'
        public int X_Viewport(decimal X_World, Rectangle Viewport, decimal MinX, decimal RangeX)
        {
            return (int)(Viewport.Left + Viewport.Width * (X_World - MinX) / RangeX);
        }

        // Y to y transformation'
        public int Y_Viewport(decimal Y_World, Rectangle Viewport, decimal MinY, decimal RangeY)
        {
            return (int)(Viewport.Top + Viewport.Height - Viewport.Height * (Y_World - MinY) / RangeY);
        }
        // ==========================================================================================================='
        

        private Dictionary<int, decimal> generatePoints(int n)
        {
            Dictionary<int, decimal> path = new Dictionary<int, decimal>();
            int num_of_success = 0;
            int i;
            for(i = 1; i <= n; i++)
            {
                int x_i = r.Next(0,2); // random 0 or 1
                if(x_i == 1)
                {
                    num_of_success++;
                    decimal f_i = Math.Round((decimal)num_of_success/(decimal)i, 3);
                    path.Add(i, f_i);
                }
                else
                {
                    decimal f_i = Math.Round((decimal)num_of_success / (decimal)i, 3);
                    path.Add(i, f_i);
                }
            }
            return path;
        }

        public Dictionary<Interval, FrequenciesForValue> UnivariateDistribution_ContinuousVariable(List<decimal> ListOfObservations, decimal IntervalSize, decimal StartingEndPoint)
        {
            var FrequencyDistribution = new Dictionary<Interval, FrequenciesForValue>();

            // First interval
            var Interval_X_0 = new Interval();
            Interval_X_0.LowerEnd = StartingEndPoint;
            Interval_X_0.UpperEnd = Interval_X_0.LowerEnd + IntervalSize;
            var ListOfIntervals_X = new List<Interval>();
            ListOfIntervals_X.Add(Interval_X_0);
            Interval Interval_Found_X;
            
            foreach (decimal d in ListOfObservations)
            {
                Interval_Found_X = null;
                Interval_Found_X = FindIntervalForValue(d, IntervalSize, ref ListOfIntervals_X);

                if (FrequencyDistribution.ContainsKey(Interval_Found_X))
                {
                    FrequencyDistribution[Interval_Found_X].Count += 1;
                }
                else
                {
                    FrequencyDistribution.Add(Interval_Found_X, new FrequenciesForValue());
                }
            }
            return FrequencyDistribution;
        }

        public Interval FindIntervalForValue(decimal v, decimal IntervalSize, ref List<Interval> ListOfIntervals)
        {
            foreach (var Interval in ListOfIntervals)
            {
                if (Interval.ContainsValue(v))
                    return Interval;
            }

            if (v <= ListOfIntervals[0].LowerEnd)
            {
                do
                {
                    var NewLeftInterval = new Interval();
                    NewLeftInterval.UpperEnd = ListOfIntervals[0].LowerEnd;
                    NewLeftInterval.LowerEnd = NewLeftInterval.UpperEnd - IntervalSize;
                    ListOfIntervals.Insert(0, NewLeftInterval);
                    if (NewLeftInterval.ContainsValue(v))
                        return NewLeftInterval;
                }
                while (true);
            }
            else if (v > ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd)
            {
                do
                {
                    var NewRightInterval = new Interval();
                    NewRightInterval.LowerEnd = ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd;
                    NewRightInterval.UpperEnd = NewRightInterval.LowerEnd + IntervalSize;
                    ListOfIntervals.Add(NewRightInterval);
                    if (NewRightInterval.ContainsValue(v))
                        return NewRightInterval;
                }
                while (true);
            }

            return default;
        }


        // ==========================================================================================================='
        // MOUSE HANDLERS'

        private Rectangle Viewport_At_Mouse_Down;
        private Point MouseLocation_At_MouseDown;
        private bool Dragging_Started;
        private bool Resizing_Started;

        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (Viewport.Contains(e.X, e.Y))
            {
                Viewport_At_Mouse_Down = Viewport;
                MouseLocation_At_MouseDown = new Point(e.X, e.Y);
                if (e.Button == MouseButtons.Left)
                {
                    Dragging_Started = true;
                }
                else if (e.Button == MouseButtons.Right)
                {
                    Resizing_Started = true;
                }
            }
        }

        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (Dragging_Started)
            {
                int Delta_X = e.X - MouseLocation_At_MouseDown.X;
                int Delta_Y = e.Y - MouseLocation_At_MouseDown.Y;
                Viewport.X = MouseLocation_At_MouseDown.X + Delta_X;
                Viewport.Y = MouseLocation_At_MouseDown.Y + Delta_Y;
            }
            else if (Resizing_Started)
            {
                int Delta_X = e.X - MouseLocation_At_MouseDown.X;
                int Delta_Y = e.Y - MouseLocation_At_MouseDown.Y;
                Viewport.Width = Viewport_At_Mouse_Down.Width + Delta_X;
                Viewport.Height = Viewport_At_Mouse_Down.Height + Delta_Y;
            }
        }

        private void PictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            Dragging_Started = false;
            Resizing_Started = false;
            drawGraphics();
        }

        private void PictureBox1_MouseWheel(object sender, MouseEventArgs e)
        {
            int Change_X = 800;
            int Change_Y = (int)(Viewport.Height * Change_X / (double)Viewport.Width);
            if (e.Delta > 0)
            {
                Viewport.X -= Change_X;
                Viewport.Width += 2 * Change_X;
                Viewport.Y -= Change_Y;
                Viewport.Height += 2 * Change_Y;
                drawGraphics();
            }
            else if (e.Delta < 0)
            {
                Viewport.X += Change_X;
                Viewport.Width -= 2 * Change_X;
                Viewport.Y += Change_Y;
                Viewport.Height -= 2 * Change_Y;
                drawGraphics();
            }
        }

        private void PictureBox1_MouseEnter(object sender, EventArgs e)
        {
            this.pictureBox1.Focus();
        }

        // ==========================================================================================================='



    }

}
